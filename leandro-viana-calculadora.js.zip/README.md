# Calculadora em JavaScript
Trabalho 2 da disciplina de Programação Web da UFMS CPPP

## Linguagens utilizadas: Pug, JavaScript e SASS
### O arquivo pug foi compilado no arquivo 
    calculator.html
### O arquivo sass foi processado no arquivo 
    syle.css 
### dentro de 
    assets/ 